# LABORATORIO 4 — AMQP + tercer protocolo: comparación con MQTT hacia IoT Central

Universidad Autónoma de Bucaramanga · Internet de las cosas
Estudiante: Miguel Antony Ortega Santa · Docente: Javier Pinzón · Fecha: [completar]
Repositorio: https://github.com/MiguelOrtega630/laboratorio4-iot-bus-urbano.git

## 1. Rol de AMQP en Azure

AMQP 1.0 es un protocolo orientado a conexión con **sesiones, enlaces (links) y control de flujo por créditos**:
el receptor le dice al emisor cuántos mensajes puede aceptar y cada entrega se confirma con una *disposition*
(aceptada, rechazada, liberada). Azure lo usa de forma intensiva en el plano de servicio (Service Bus, Event Hubs,
el endpoint compatible con Event Hubs de IoT Hub) porque ahí importan las garantías de entrega y el
back-pressure. En el plano de dispositivo, IoT Hub/IoT Central aceptan MQTT, AMQP y HTTPS (y sus variantes
sobre WebSockets). MQTT es más liviano para dispositivos pequeños; AMQP resuelve mejor la confirmación por
mensaje, la multiplexación de varios links en una conexión y el flujo controlado entre servicios.

## 2. AMQP hacia IoT Central (evidencia)

- Flujo implementado (`amqp_publisher.py`): DPS → TLS al Hub por el puerto 5671 → autenticación CBS (`put-token`
  al nodo `$cbs` con SAS token) → sender link a `/devices/{id}/messages/events`.
- Aclaración técnica: `azure-iot-device` de Python no soporta AMQP, por lo que se usó `python-qpid-proton`.
- Puerto: 5671 · TLS: sí · Autenticación: SASL ANONYMOUS + CBS (a diferencia de MQTT, donde el SAS va en la contraseña).
- [Captura: terminal AMQP]  [Captura: Data explorer con las 3 variables]
- Diferencias observadas frente a MQTT del Lab 3: [completar con lo que viste: tiempo de conexión, ack por mensaje en
  el log, complejidad del script, qué hubo que depurar].

## 3. Tercer protocolo: HTTPS

- Justificación de negocio: un bus que solo reporta cada pocos minutos, o que sale por un proxy corporativo
  que solo permite el puerto 443, no necesita sesión persistente; HTTPS se depura con `curl` y se integra con
  cualquier lenguaje sin librerías de mensajería.
- Implementación: `https_publisher.py`, POST a `https://{hub}/devices/{id}/messages/events` con SAS en la cabecera
  `Authorization`; respuesta `204`.
- Ventajas: pasa cualquier firewall, trivial de depurar, sin estado. Desventajas: cabeceras HTTP y (sin keep-alive)
  handshake TLS en cada mensaje, sin push de la nube al dispositivo (hay que consultar), más costoso por mensaje.
- [Captura: terminal HTTPS con 204]  [Captura: Data explorer]
- Complejidad real: [completar].

## 4. Tabla comparativa

| Criterio | MQTT | AMQP 1.0 | HTTPS |
|---|---|---|---|
| Puerto | 8883 (443 con WebSockets) | 5671 (443 con WebSockets) | 443 |
| Transporte | TCP + TLS, conexión persistente | TCP + TLS, conexión persistente, sesiones y links | TCP + TLS, petición/respuesta |
| Overhead | Muy bajo (cabecera mínima de 2 bytes) | Medio (framing, performatives, créditos) | Alto (cabeceras HTTP; handshake TLS si no hay keep-alive) |
| Latencia percibida | [medida] | [medida, ack por mensaje] | [medida, rtt por POST] |
| Fiabilidad | QoS 0 y 1 (IoT Hub no soporta QoS 2) | Confirmación por entrega con estados de disposition y control de flujo | Código HTTP por petición; el reintento lo implementa la app |
| Mensajes nube→dispositivo | Sí (suscripción) | Sí (link de recepción) | No hay push, solo consulta periódica |
| Soporte en microcontrolador / Wokwi | Excelente (PubSubClient) | Pobre (sin librería AMQP ligera estándar para ESP32) | Bueno (HTTPClient) |
| Facilidad de debug | Media | Baja | Alta (curl, navegador) |
| Paso de firewalls | 8883 suele bloquearse; MQTT-WS en 443 | 5671 suele bloquearse; AMQP-WS en 443 | Casi siempre permitido |
| Caso de uso ideal | Telemetría frecuente de dispositivos con pocos recursos | Mensajería entre servicios, garantías ricas, gateways | Dispositivos que reportan poco o detrás de proxies restrictivos |

Completa las filas marcadas `[medida]` con los CSV de `/evidencias/mediciones`.

## 5. Recomendaciones por capa

- **Dispositivo (Wokwi / ESP futuro):** MQTT sobre TLS. Es el más liviano, tiene librería madura para ESP32 y
  permite comandos de vuelta.
- **Entre servicios Azure o en la plataforma propia (Labs 5–8):** AMQP. Aporta confirmación por mensaje, control
  de flujo y es el protocolo natural de Service Bus y Event Hubs.
- **Quedarse con dos protocolos:** MQTT (borde) y AMQP (servicios). HTTPS queda como plan B cuando un firewall
  bloquee los otros dos, no como protocolo principal.
