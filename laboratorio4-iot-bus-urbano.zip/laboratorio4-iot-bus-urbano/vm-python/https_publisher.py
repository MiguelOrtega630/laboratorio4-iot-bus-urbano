"""Tercer protocolo: HTTPS (REST) hacia Azure IoT Hub, el Hub asignado por DPS a IoT Central.

Cada muestra es un POST independiente (sin conexión de aplicación persistente):
  POST https://{hub}/devices/{deviceId}/messages/events?api-version=2020-09-30
  Authorization: SharedAccessSignature sr=...&sig=...&se=...
  Respuesta esperada: 204 No Content

Justificación de negocio: un sensor que reporta una vez cada varios minutos (o a través de un
proxy corporativo que solo deja pasar 443) no necesita mantener sesión; HTTPS es trivial de
depurar con curl. Costo: cabeceras + handshake repetidos y sin push del nube al dispositivo.

Uso:  python https_publisher.py --interval 10 --csv ../evidencias/mediciones/https.csv
"""
import argparse
import csv
import json
import os
import time

import requests

from common import BusState, env, provision, sas_token

API_VERSION = "2020-09-30"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--interval", type=float, default=10.0)
    parser.add_argument("--count", type=int, default=0, help="0 = infinito")
    parser.add_argument("--csv", default="")
    parser.add_argument("--no-keepalive", action="store_true",
                        help="una conexión TCP/TLS nueva por mensaje (peor caso HTTPS)")
    args = parser.parse_args()

    id_scope = env("IOTC_ID_SCOPE")
    registration_id = env("IOTC_DEVICE_ID")
    key = env("IOTC_DEVICE_KEY")

    print("Registrando dispositivo via DPS...")
    hub, device_id = provision(id_scope, registration_id, key)
    print(f"Hub asignado: {hub} | Device ID asignado: {device_id}")

    url = f"https://{hub}/devices/{device_id}/messages/events?api-version={API_VERSION}"
    audience = f"{hub}/devices/{device_id}"
    token, token_expiry = None, 0
    session = requests.Session()

    writer = None
    if args.csv:
        os.makedirs(os.path.dirname(args.csv) or ".", exist_ok=True)
        fh = open(args.csv, "a", newline="")
        writer = csv.writer(fh)
        if fh.tell() == 0:
            writer.writerow(["timestamp_utc", "payload_bytes", "http_status", "rtt_ms",
                             "temperatura", "velocidad", "combustible"])

    bus = BusState()
    sent = 0
    print(f"Enviando por HTTPS cada {args.interval:g}s. Ctrl+C para detener.\n")
    try:
        while args.count == 0 or sent < args.count:
            if time.time() > token_expiry - 300:
                token = sas_token(audience, key, 3600)
                token_expiry = time.time() + 3600
            data = bus.next()
            body = json.dumps(data)
            headers = {"Authorization": token, "Content-Type": "application/json"}
            if args.no_keepalive:
                headers["Connection"] = "close"
            t = time.time()
            try:
                resp = session.post(url, data=body, headers=headers, timeout=15)
                status = resp.status_code
            except requests.RequestException as exc:
                status = f"ERR {type(exc).__name__}"
            rtt_ms = 1000 * (time.time() - t)
            sent += 1
            print(f"[{device_id}] HTTPS {status} ({len(body)} B, rtt {rtt_ms:.0f} ms): {data}")
            if writer:
                writer.writerow([time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), len(body),
                                 status, f"{rtt_ms:.0f}", data["TemperaturaDelMotor"],
                                 data["VelocidadDelBus"], data["NivelDeCombustible"]])
                fh.flush()
            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\nDetenido por el usuario.")


if __name__ == "__main__":
    main()
