"""Utilidades compartidas: variables de entorno, DPS, SAS token y telemetría sintética."""
import base64
import hashlib
import hmac
import os
import random
import time
import urllib.parse

from azure.iot.device import ProvisioningDeviceClient

DPS_HOST = "global.azure-devices-provisioning.net"


def env(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        raise SystemExit(f"Falta la variable de entorno {name} (ver .env.example)")
    return value


def provision(id_scope: str, device_id: str, key: str):
    """Registra el dispositivo en DPS y devuelve (assigned_hub, assigned_device_id).

    DPS lo hace el SDK por MQTT: el Lab 4 cambia solo el transporte hacia el Hub.
    """
    client = ProvisioningDeviceClient.create_from_symmetric_key(
        provisioning_host=DPS_HOST,
        registration_id=device_id,
        id_scope=id_scope,
        symmetric_key=key,
    )
    result = client.register()
    if result.status != "assigned":
        raise SystemExit(f"DPS no asignó el dispositivo: {result.status}")
    state = result.registration_state
    return state.assigned_hub, state.device_id


def sas_token(resource_uri: str, key: str, expiry_seconds: int = 3600) -> str:
    """SAS token HMAC-SHA256 (igual que en el Lab 3)."""
    expiry = int(time.time()) + expiry_seconds
    encoded = urllib.parse.quote(resource_uri, safe="")
    to_sign = f"{encoded}\n{expiry}".encode()
    signature = hmac.new(base64.b64decode(key), to_sign, hashlib.sha256).digest()
    sig = urllib.parse.quote(base64.b64encode(signature).decode(), safe="")
    return f"SharedAccessSignature sr={encoded}&sig={sig}&se={expiry}"


class BusState:
    """Genera valores coherentes: la temperatura sube con la velocidad y el combustible baja."""

    def __init__(self):
        self.temp = 75.0
        self.speed = 40.0
        self.fuel = 90.0

    def next(self) -> dict:
        self.speed = min(90.0, max(0.0, self.speed + random.uniform(-6, 6)))
        self.temp = min(110.0, max(60.0, self.temp + (self.speed - 45) * 0.02 + random.uniform(-0.8, 0.8)))
        self.fuel = max(0.0, self.fuel - random.uniform(0.0, 0.15))
        return {
            "TemperaturaDelMotor": round(self.temp, 1),
            "VelocidadDelBus": round(self.speed, 1),
            "NivelDeCombustible": round(self.fuel, 1),
        }
