"""Publicador AMQP 1.0 hacia Azure IoT Hub (el Hub asignado por DPS a IoT Central).

Por qué no azure-iot-device: el SDK de Python solo habla MQTT (y MQTT sobre WebSockets).
Los parámetros AMQP / AMQP_WS existen en los SDK de Node, C# y Java. Aquí se reproduce a mano
lo que haría un SDK AMQP, con python-qpid-proton:

  1. DPS (SDK)            -> assigned_hub + assigned_device_id
  2. TLS 5671 + SASL ANONYMOUS al Hub
  3. Autenticación CBS    -> mensaje put-token al nodo "$cbs" con el SAS token
  4. Sender link          -> /devices/{id}/messages/events
  5. Un mensaje AMQP por muestra; el Hub confirma (disposition) cada entrega

Uso:  python amqp_publisher.py --interval 5 --csv ../evidencias/mediciones/amqp.csv
"""
import argparse
import csv
import json
import os
import ssl
import sys
import time
import uuid

from proton import Message, SSLDomain
from proton.utils import BlockingConnection

from common import BusState, env, provision, sas_token

TOKEN_TTL = 3600
RENEW_BEFORE = 300  # renovar el token 5 min antes de que expire


def ca_bundle() -> str:
    try:
        import certifi
        return certifi.where()
    except ImportError:
        return ssl.get_default_verify_paths().cafile or "/etc/ssl/certs/ca-certificates.crt"


def put_token(conn, audience: str, key: str) -> None:
    """Autenticación Claims-Based Security (CBS) sobre el nodo $cbs."""
    sender = conn.create_sender("$cbs", name=f"cbs-tx-{uuid.uuid4().hex[:6]}")
    receiver = conn.create_receiver("$cbs", name=f"cbs-rx-{uuid.uuid4().hex[:6]}")
    token = sas_token(audience, key, TOKEN_TTL)
    request = Message(
        body=token,
        id=str(uuid.uuid4()),
        reply_to="cbs",
        address="$cbs",
        properties={
            "operation": "put-token",
            "type": "servicebus.windows.net:sastoken",
            "name": audience,
        },
    )
    sender.send(request, timeout=15)
    response = receiver.receive(timeout=15)
    receiver.accept()
    status = (response.properties or {}).get("status-code")
    sender.close()
    receiver.close()
    if status not in (200, 202):
        desc = (response.properties or {}).get("status-description")
        raise SystemExit(f"CBS rechazó el token: {status} {desc}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--interval", type=float, default=5.0, help="segundos entre mensajes")
    parser.add_argument("--count", type=int, default=0, help="0 = infinito")
    parser.add_argument("--csv", default="", help="archivo CSV para las mediciones")
    args = parser.parse_args()

    id_scope = env("IOTC_ID_SCOPE")
    registration_id = env("IOTC_DEVICE_ID")
    key = env("IOTC_DEVICE_KEY")

    print("Registrando dispositivo via DPS...")
    hub, device_id = provision(id_scope, registration_id, key)
    print(f"Hub asignado: {hub} | Device ID asignado: {device_id}")

    ssl_domain = SSLDomain(SSLDomain.MODE_CLIENT)
    if sys.platform != "win32":
        # OpenSSL (Linux/macOS): hay que indicar el archivo de CAs.
        ssl_domain.set_trusted_ca_db(ca_bundle())
    # En Windows Proton usa Schannel, que valida contra el almacén de certificados del
    # sistema y no acepta un archivo PEM (set_trusted_ca_db falla con "SSL failure").
    ssl_domain.set_peer_authentication(SSLDomain.VERIFY_PEER_NAME)

    t0 = time.time()
    conn = BlockingConnection(f"amqps://{hub}:5671", ssl_domain=ssl_domain,
                              allowed_mechs="ANONYMOUS", heartbeat=60, timeout=30)
    audience = f"{hub}/devices/{device_id}"
    put_token(conn, audience, key)
    token_expiry = time.time() + TOKEN_TTL
    sender = conn.create_sender(f"/devices/{device_id}/messages/events", name="telemetry")
    print(f"AMQP conectado (puerto 5671, TLS, CBS ok) en {1000 * (time.time() - t0):.0f} ms. "
          f"Enviando cada {args.interval:g}s. Ctrl+C para detener.\n")

    writer = None
    if args.csv:
        os.makedirs(os.path.dirname(args.csv) or ".", exist_ok=True)
        fh = open(args.csv, "a", newline="")
        writer = csv.writer(fh)
        if fh.tell() == 0:
            writer.writerow(["timestamp_utc", "payload_bytes", "ack_ms", "temperatura", "velocidad", "combustible"])

    bus = BusState()
    sent = 0
    try:
        while args.count == 0 or sent < args.count:
            if time.time() > token_expiry - RENEW_BEFORE:
                put_token(conn, audience, key)
                token_expiry = time.time() + TOKEN_TTL
                print(">>> Token SAS renovado vía CBS")
            data = bus.next()
            body = json.dumps(data).encode("utf-8")
            msg = Message(body=body, content_type="application/json", content_encoding="utf-8")
            msg.inferred = True  # cuerpo binario -> sección AMQP DATA
            t = time.time()
            sender.send(msg, timeout=15)  # vuelve cuando el Hub confirma la entrega
            ack_ms = 1000 * (time.time() - t)
            sent += 1
            print(f"[{device_id}] AMQP enviado ({len(body)} B, ack {ack_ms:.0f} ms): {data}")
            if writer:
                writer.writerow([time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), len(body),
                                 f"{ack_ms:.0f}", data["TemperaturaDelMotor"],
                                 data["VelocidadDelBus"], data["NivelDeCombustible"]])
                fh.flush()
            time.sleep(args.interval)
    except KeyboardInterrupt:
        print("\nDetenido por el usuario.")
    finally:
        conn.close()


if __name__ == "__main__":
    main()